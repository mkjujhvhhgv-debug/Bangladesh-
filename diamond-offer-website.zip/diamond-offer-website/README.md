# NOVA TOPUP — All Games Diamond Shop

A Python-free starter project built with Node.js, Express, SQLite, HTML, CSS and vanilla JavaScript. It includes a customer storefront and a separate `/admin` dashboard.

## Requirements
- Node.js 20+
- npm

## Install and run
1. Extract the ZIP.
2. In this project folder run `npm install`.
3. Copy `.env.example` to `.env`.
4. Set a long random `JWT_SECRET` (at least 32 characters), a strong `ADMIN_PASSWORD` (at least 12 characters), `ADMIN_USERNAME`, and your bKash/Nagad/Rocket receiving numbers.
5. Run `npm start`.
6. Open `http://localhost:3000` for the shop and `http://localhost:3000/admin` for the separate admin login.

The admin account is created on first start if the configured username does not already exist. If you change the admin password in `.env` after the account has been created, it does not automatically overwrite the existing password; change it securely in the database or use a fresh database during initial setup.

## Important payment and delivery behavior
- bKash, Nagad and Rocket are currently **manual payment collection**: the site displays your configured receiving number and records the transaction ID. Admin must independently verify the payment in the relevant merchant/personal wallet before clicking **Verify + deliver**.
- This project does **not** claim to have live bKash/Nagad/Rocket payment-gateway integration. To accept automatic payments, obtain official merchant API credentials and implement the provider's verified callback/webhook flow. Never trust a transaction ID submitted by a customer as proof of payment.
- Automatic game delivery requires a real top-up supplier/provider API. Set `DELIVERY_API_URL` and `DELIVERY_API_KEY` in `.env`. The adapter sends a POST request with this JSON:
  ```json
  {
    "external_order_id": "123",
    "game": "Free Fire",
    "package": "100 Diamonds",
    "player_id": "123456789",
    "server_id": "",
    "amount_bdt": 100
  }
  ```
  It sends the API key in the header named by `DELIVERY_API_TOKEN_HEADER` (default `Authorization`), with prefix `DELIVERY_API_TOKEN_PREFIX` (default `Bearer`). The provider response should be JSON with optional `reference`, `order_id`, and `message`. Adjust `deliverOrder()` in `server.js` to match your supplier's documented API, authentication, response and status polling requirements. Do not configure an untrusted API endpoint.
- The admin's **Verify + deliver** action first marks an order as processing and then submits it to the configured provider. If the provider is not configured or returns an error, the order is marked failed and the error is shown. Admin can retry after checking provider status to avoid duplicate top-ups.

## Add packages
Log in as admin at `/admin`. Use the Add package form to create game/package offers. Hide a package to remove it from the public storefront without deleting its order history.

## Production checklist
- Use HTTPS and set `BASE_URL` to your actual origin.
- Use a strong unique JWT secret and admin password; do not commit `.env`.
- Restrict server/database file access and configure regular encrypted backups.
- Add CSRF protection if you later switch to cookie-based authentication.
- Add a provider-specific idempotency key and order reconciliation before enabling live delivery. The sample uses the local order ID as external order ID, but provider idempotency support varies.
- Add official payment gateway webhooks and verify signatures server-side before automatic fulfillment.
- Review local consumer protection, tax, privacy and payment-provider requirements.
- The initial database contains no products; add packages from the admin dashboard.

## Project structure
- `server.js` — API, authentication, database and delivery adapter
- `public/index.html`, `public/app.js`, `public/style.css` — customer shop
- `public/admin.html`, `public/admin.js` — separate admin dashboard
- `.env.example` — configuration template
