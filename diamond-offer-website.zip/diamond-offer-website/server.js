require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error("Set JWT_SECRET to a random value of at least 32 characters in .env");
  process.exit(1);
}

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.BASE_URL || false }));
app.use(express.json({ limit: "30kb" }));
app.use(express.urlencoded({ extended: false, limit: "30kb" }));
app.use("/api", rateLimit({ windowMs: 15 * 60 * 1000, limit: 250, standardHeaders: true, legacyHeaders: false }));

const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "shop.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT, game TEXT NOT NULL, title TEXT NOT NULL,
 description TEXT DEFAULT '', price INTEGER NOT NULL CHECK(price > 0),
 active INTEGER DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
 product_id INTEGER NOT NULL, player_id TEXT NOT NULL, server_id TEXT DEFAULT '',
 payment_method TEXT NOT NULL, transaction_id TEXT NOT NULL,
 amount INTEGER NOT NULL, status TEXT DEFAULT 'pending',
 delivery_ref TEXT DEFAULT '', delivery_message TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(product_id) REFERENCES products(id)
);
`);

const seedAdmin = async () => {
  const username = process.env.ADMIN_USERNAME || "admin";
  const password = process.env.ADMIN_PASSWORD;
  if (!password || password.length < 12) {
    console.warn("ADMIN_PASSWORD is not set or too short; admin account was not seeded.");
    return;
  }
  const existing = db.prepare("SELECT id FROM users WHERE username=?").get(username);
  if (!existing) {
    const hash = await bcrypt.hash(password, 12);
    db.prepare("INSERT INTO users(username,password_hash) VALUES(?,?)").run(username, hash);
    console.log(`Admin account created: ${username}`);
  }
};

function signToken(user) {
  return jwt.sign({ id: user.id, username: user.username, role: user.role || "user" }, JWT_SECRET, { expiresIn: "12h" });
}
function auth(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  try {
    if (!token) throw new Error("missing");
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch { res.status(401).json({ error: "Please log in again." }); }
}
function adminOnly(req, res, next) {
  if (req.user.username !== (process.env.ADMIN_USERNAME || "admin")) return res.status(403).json({ error: "Admin access required." });
  next();
}
const clean = (v, max=120) => String(v ?? "").trim().slice(0, max);
const paymentNumbers = () => ({
  bKash: process.env.BKASH_NUMBER || "Set receiver number in .env",
  Nagad: process.env.NAGAD_NUMBER || "Set receiver number in .env",
  Rocket: process.env.ROCKET_NUMBER || "Set receiver number in .env"
});

app.get("/api/config", (req,res) => res.json({ shopName: "NOVA TOPUP", payments: paymentNumbers() }));

app.post("/api/auth/register", async (req,res) => {
  const username = clean(req.body.username, 30);
  const password = String(req.body.password || "");
  if (!/^[a-zA-Z0-9_]{3,30}$/.test(username) || password.length < 8)
    return res.status(400).json({ error: "Username: 3–30 letters/numbers/_. Password: at least 8 characters." });
  try {
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare("INSERT INTO users(username,password_hash) VALUES(?,?)").run(username, hash);
    const user = { id: Number(info.lastInsertRowid), username };
    res.json({ token: signToken(user), username });
  } catch { res.status(409).json({ error: "Username already exists." }); }
});

app.post("/api/auth/login", async (req,res) => {
  const username = clean(req.body.username, 30);
  const user = db.prepare("SELECT * FROM users WHERE username=?").get(username);
  if (!user || !(await bcrypt.compare(String(req.body.password || ""), user.password_hash)))
    return res.status(401).json({ error: "Incorrect username or password." });
  const role = username === (process.env.ADMIN_USERNAME || "admin") ? "admin" : "user";
  res.json({ token: signToken({ id: user.id, username, role }), username, role });
});

app.get("/api/products", (req,res) => {
  res.json(db.prepare("SELECT id,game,title,description,price FROM products WHERE active=1 ORDER BY game,id").all());
});

app.post("/api/orders", auth, (req,res) => {
  const productId = Number(req.body.productId);
  const playerId = clean(req.body.playerId, 80);
  const serverId = clean(req.body.serverId, 40);
  const method = clean(req.body.paymentMethod, 20);
  const transactionId = clean(req.body.transactionId, 100);
  if (!productId || !playerId || !transactionId || !["bKash","Nagad","Rocket"].includes(method))
    return res.status(400).json({ error: "Complete all order and payment fields." });
  const product = db.prepare("SELECT * FROM products WHERE id=? AND active=1").get(productId);
  if (!product) return res.status(404).json({ error: "Package not found." });
  const result = db.prepare(`INSERT INTO orders(user_id,product_id,player_id,server_id,payment_method,transaction_id,amount)
    VALUES(?,?,?,?,?,?,?)`).run(req.user.id, productId, playerId, serverId, method, transactionId, product.price);
  res.status(201).json({ message: "Order submitted. It will be processed after payment verification.", orderId: Number(result.lastInsertRowid) });
});

app.get("/api/orders/mine", auth, (req,res) => {
  res.json(db.prepare(`SELECT o.*,p.game,p.title FROM orders o JOIN products p ON p.id=o.product_id
    WHERE o.user_id=? ORDER BY o.id DESC`).all(req.user.id));
});

// Delivery adapter: configure a real provider endpoint/key in .env.
// Generic JSON contract is described in README. Do not mark an order delivered on API failure.
async function deliverOrder(order, product) {
  const endpoint = process.env.DELIVERY_API_URL;
  const apiKey = process.env.DELIVERY_API_KEY;
  if (!endpoint || !apiKey) return { ok: false, message: "Delivery provider is not configured. Configure DELIVERY_API_URL and DELIVERY_API_KEY." };
  const headerName = process.env.DELIVERY_API_TOKEN_HEADER || "Authorization";
  const prefix = process.env.DELIVERY_API_TOKEN_PREFIX ?? "Bearer";
  const tokenValue = prefix ? `${prefix} ${apiKey}` : apiKey;
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json", [headerName]: tokenValue },
      body: JSON.stringify({
        external_order_id: String(order.id), game: product.game, package: product.title,
        player_id: order.player_id, server_id: order.server_id, amount_bdt: order.amount
      }),
      signal: AbortSignal.timeout(20000)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return { ok: false, message: clean(data.message || `Provider HTTP ${response.status}`, 250) };
    return { ok: true, reference: clean(data.reference || data.order_id || "", 100), message: clean(data.message || "Provider accepted the delivery request.", 250) };
  } catch (e) { return { ok: false, message: clean(e.message, 250) }; }
}

app.get("/api/admin/overview", auth, adminOnly, (req,res) => {
  const counts = db.prepare(`SELECT COUNT(*) total,
    SUM(status='pending') pending, SUM(status='processing') processing,
    SUM(status='delivered') delivered, SUM(status='failed') failed FROM orders`).get();
  const revenue = db.prepare("SELECT COALESCE(SUM(amount),0) total FROM orders WHERE status='delivered'").get().total;
  res.json({ counts, revenue });
});
app.get("/api/admin/orders", auth, adminOnly, (req,res) => {
  res.json(db.prepare(`SELECT o.*,u.username,p.game,p.title FROM orders o
    JOIN users u ON u.id=o.user_id JOIN products p ON p.id=o.product_id ORDER BY o.id DESC LIMIT 300`).all());
});
app.post("/api/admin/orders/:id/verify-and-deliver", auth, adminOnly, async (req,res) => {
  const id = Number(req.params.id);
  const order = db.prepare("SELECT * FROM orders WHERE id=?").get(id);
  if (!order) return res.status(404).json({ error: "Order not found." });
  if (order.status === "delivered") return res.status(409).json({ error: "Already delivered." });
  const product = db.prepare("SELECT * FROM products WHERE id=?").get(order.product_id);
  db.prepare("UPDATE orders SET status='processing' WHERE id=?").run(id);
  const result = await deliverOrder(order, product);
  if (result.ok) {
    db.prepare("UPDATE orders SET status='delivered',delivery_ref=?,delivery_message=? WHERE id=?")
      .run(result.reference, result.message, id);
    res.json({ message: "Provider accepted the delivery request.", status: "delivered", reference: result.reference });
  } else {
    db.prepare("UPDATE orders SET status='failed',delivery_message=? WHERE id=?").run(result.message, id);
    res.status(502).json({ error: result.message, status: "failed" });
  }
});
app.post("/api/admin/orders/:id/reject", auth, adminOnly, (req,res) => {
  const result = db.prepare("UPDATE orders SET status='rejected',delivery_message=? WHERE id=? AND status IN ('pending','failed')")
    .run(clean(req.body.reason || "Payment/order rejected by admin.", 250), Number(req.params.id));
  if (!result.changes) return res.status(400).json({ error: "Order cannot be rejected." });
  res.json({ message: "Order rejected." });
});
app.post("/api/admin/products", auth, adminOnly, (req,res) => {
  const game=clean(req.body.game,60), title=clean(req.body.title,100), description=clean(req.body.description,250), price=Number(req.body.price);
  if (!game || !title || !Number.isInteger(price) || price < 1) return res.status(400).json({error:"Game, package title and valid BDT price are required."});
  const info=db.prepare("INSERT INTO products(game,title,description,price) VALUES(?,?,?,?)").run(game,title,description,price);
  res.status(201).json({id:Number(info.lastInsertRowid)});
});
app.patch("/api/admin/products/:id", auth, adminOnly, (req,res) => {
  const p=db.prepare("SELECT * FROM products WHERE id=?").get(Number(req.params.id));
  if(!p) return res.status(404).json({error:"Package not found."});
  const game=clean(req.body.game ?? p.game,60), title=clean(req.body.title ?? p.title,100);
  const description=clean(req.body.description ?? p.description,250), price=Number(req.body.price ?? p.price);
  const active=req.body.active === undefined ? p.active : (req.body.active ? 1 : 0);
  if(!game || !title || !Number.isInteger(price) || price<1) return res.status(400).json({error:"Invalid package data."});
  db.prepare("UPDATE products SET game=?,title=?,description=?,price=?,active=? WHERE id=?").run(game,title,description,price,active, p.id);
  res.json({message:"Package updated."});
});
app.delete("/api/admin/products/:id", auth, adminOnly, (req,res) => {
  db.prepare("UPDATE products SET active=0 WHERE id=?").run(Number(req.params.id));
  res.json({message:"Package hidden."});
});

app.use(express.static(path.join(__dirname, "public")));
app.get("/admin", (req,res) => res.sendFile(path.join(__dirname,"public","admin.html")));
app.get("*", (req,res) => res.sendFile(path.join(__dirname,"public","index.html")));

seedAdmin().then(() => app.listen(PORT, () => console.log(`NOVA TOPUP running on port ${PORT}`)));
